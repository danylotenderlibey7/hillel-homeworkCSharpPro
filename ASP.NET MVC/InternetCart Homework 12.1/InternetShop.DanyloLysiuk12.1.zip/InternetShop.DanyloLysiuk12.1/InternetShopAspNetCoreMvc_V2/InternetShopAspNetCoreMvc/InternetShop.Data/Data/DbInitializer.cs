﻿using InternetShop.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace InternetShop.Data.Data
{
	public class DbInitializer
	{
		private readonly ModelBuilder _modelBuilder;

		public DbInitializer(ModelBuilder modelBuilder)
		{
			_modelBuilder = modelBuilder;
		}

		public void Seed()
		{
			_modelBuilder.Entity<User>(x =>
			{
				x.HasData(new User
				{
					Id = 1,
					Username = "Danylo",
					Email = "ddd@gmail.com",
					Address = "test-1",
					Fullname = "Danylo Tender",
					CreatedAt = DateTime.UtcNow
				});
				x.HasData(new User
				{
					Id = 2,
					Username = "Petya",
					Email = "petya@gmail.com",
					Address = "test-2",
					Fullname = "Petya Pupkin",
					CreatedAt = DateTime.UtcNow
				});
			});
		}
	}
}
