﻿using Microsoft.AspNetCore.Mvc;

namespace InternetShop.API.Controllers
{
	public class PageNotFoundController : Controller
	{
        public IActionResult Index()
        {
            return View();
        }
    }
}
