﻿using AspNetCoreHero.ToastNotification.Abstractions;
using InternetShop.Data.Data;
using InternetShop.Service.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;

public class OrdersController : Controller
{
    private readonly InternetShopDbContext _context;
    private readonly IOrdersRepository ordersRepository;
    private readonly ICartRepository cartRepository;
    private readonly ILogger<OrdersController> _logger;
    private readonly INotyfService _notifyService;
    private const int UserId = 1;

    public OrdersController(
        InternetShopDbContext context,
        IOrdersRepository ordersRepository,
        ICartRepository cartRepository,
        ILogger<OrdersController> logger,
        INotyfService notifyService)
    {
        _context = context;
        this.ordersRepository = ordersRepository;
        this.cartRepository = cartRepository;
        _notifyService = notifyService;
        _logger = logger;
    }

    public IActionResult Manage()
    {
        var orders = ordersRepository.GetAllOrdersWithDetails();
        return View(orders);
    }

    public IActionResult Index()
    {
        var orders = ordersRepository.GetUserOrdersWithDetails(UserId);

        if (orders == null || !orders.Any())
        {
            _logger.LogWarning("No orders found for UserId {UserId}", UserId);
        }

        return View(orders);
    }

    public IActionResult Details(int id)
    {
        var order = ordersRepository.GetOrderWithDetails(id);

        if (order != null)
        {
            return View(order);
        }

        return View("DoesNotExist");
    }

    [HttpGet]
    public IActionResult PlaceOrder()
    {
        var orderItems = cartRepository.GetUserCartItems(UserId);
        ViewData["total"] = orderItems.Select(c => c.Product.Price * c.Quantity).Sum() + 10;

        return View(orderItems);
    }

    public IActionResult PlaceOrderConfirmed()
    {
        ordersRepository.ConfirmOrder(UserId);
        return RedirectToAction("Index");
    }

    /*[HttpGet]
    public IActionResult Edit(int id)
    {
        var orderItem = ordersRepository.GetOrderWithDetails(id);

        if (orderItem != null)
        {
            return View(orderItem);
        }

        return RedirectToAction("Index");
    }*/

/*    [HttpPost]
    public IActionResult Edit(Order order)
    {
        if (ModelState.IsValid)
        {
            ordersRepository.UpdateOrder(order);
            _notifyService.Success("Changed successfully!");
            return RedirectToAction("Index");
        }

        return View(order);
    }

    [HttpPost]
    public IActionResult EditCartItem(CartItem item)
    {
        cartRepository.UpdateCartItem(item);
        _notifyService.Success("Changed successfully!");
        return RedirectToAction("CartIndex");
    }*/

    [HttpGet]
    public IActionResult Delete(int id)
    {
        var order = ordersRepository.GetOrderWithDetails(id);
        if (order != null)
        {
            return View(order);
        }
        _notifyService.Error("Product not found!");

        return RedirectToAction("Index");

    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        ordersRepository.DeleteOrder(id);  // Удаление заказа
        _notifyService.Success("Order deleted successfully!");
        return RedirectToAction("Index");
    }
    }
