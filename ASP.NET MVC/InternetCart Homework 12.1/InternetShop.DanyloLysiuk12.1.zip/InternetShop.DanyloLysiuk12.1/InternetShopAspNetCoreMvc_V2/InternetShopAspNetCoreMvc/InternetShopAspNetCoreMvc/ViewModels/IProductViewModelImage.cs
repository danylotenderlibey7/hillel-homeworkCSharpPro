﻿namespace InternetShop.API.ViewModels
{
    public interface IProductViewModelImage
    {
        IFormFile Image { get; set; }
    }
}
