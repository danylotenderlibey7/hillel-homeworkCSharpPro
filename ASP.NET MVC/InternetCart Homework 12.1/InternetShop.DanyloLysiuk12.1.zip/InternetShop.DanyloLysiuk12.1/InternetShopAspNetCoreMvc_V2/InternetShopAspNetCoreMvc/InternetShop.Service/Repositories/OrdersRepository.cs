﻿using InternetShop.Data.Data;
using InternetShop.Data.Models;
using InternetShop.Service.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace InternetShop.Service.Repositories
{
    public class OrdersRepository : IOrdersRepository
    {
        private readonly InternetShopDbContext _context;

        public OrdersRepository(InternetShopDbContext context)
        {
            _context = context;
        }

        public List<Order> GetAllOrdersWithDetails()
        {
            return _context.Orders
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Product)
                .ToList();
        }

        public List<Order> GetAllOrders()
        {
            return _context.Orders
                .AsNoTracking()
                .ToList();
        }

        public Order GetOrderWithDetails(int id)
        {
            return _context.Orders
                .AsNoTracking()
                .Include(x => x.OrderDetails)
                .ThenInclude(x => x.Product)
                .FirstOrDefault(x => x.Id == id);
        }

        public List<Order> GetUserOrders(int id)
        {
            return _context.Orders
                .AsNoTracking()
                .Where(x => x.UserId == id)
                .ToList();
        }

        public List<Order> GetUserOrdersWithDetails(int id)
        {
            return _context.Orders
                .Where(o => o.UserId == id)
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Product)
                .ToList();
        }

        public void UpdateCartItem(CartItem cartItem)
        {
            var existingCartItem = _context.CartItems
                .FirstOrDefault(c => c.Id == cartItem.Id);

            if (existingCartItem != null)
            {
                existingCartItem.Quantity = cartItem.Quantity;
                _context.SaveChanges();
            }
        }

        public void ConfirmOrder(int userId)
        {
            var cartItems = _context.CartItems
                .Include(c => c.Product)
                .Where(c => c.UserId == userId)
                .ToList();

            if (cartItems != null && cartItems.Count > 0)
            {
                using var transaction = _context.Database.BeginTransaction();
                try
                {
                    var totalWithNoTax = cartItems.Select(c => c.Product.Price * c.Quantity).Sum();
                    var order = new Order
                    {
                        UserId = userId,
                        CreatedAt = DateTime.Now,
                        Amount = totalWithNoTax
                    };
                    _context.Orders.Add(order);
                    _context.SaveChanges();

                    foreach (var item in cartItems)
                    {
                        var orderDetails = new OrderDetail
                        {
                            OrderId = order.Id,
                            ProductId = item.ProductId,
                            Price = item.Product.Price,
                            Quantity = item.Quantity,
                            Total = item.Quantity * item.Product.Price
                        };
                        _context.OrderDetails.Add(orderDetails);
                        _context.CartItems.Remove(item);
                    }
                    _context.SaveChanges();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    // Add logging
                }
            }
        }

        public void UpdateOrder(Order order)
        {
            var existingOrder = _context.Orders
                .Include(o => o.OrderDetails)
                .FirstOrDefault(o => o.Id == order.Id);

            if (existingOrder != null)
            {
                existingOrder.Amount = order.Amount;
                existingOrder.CreatedAt = order.CreatedAt;

                foreach (var detail in order.OrderDetails)
                {
                    var existingDetail = existingOrder.OrderDetails
                        .FirstOrDefault(d => d.ProductId == detail.ProductId);

                    if (existingDetail != null)
                    {
                        existingDetail.Quantity = detail.Quantity;
                        existingDetail.Total = detail.Quantity * existingDetail.Price;
                    }
                }

                _context.SaveChanges();
            }
        }

        public void DeleteOrder(int orderId)
        {
            var order = _context.Orders
                .Include(o => o.OrderDetails)
                .FirstOrDefault(o => o.Id == orderId);

            if (order != null)
            {
                _context.OrderDetails.RemoveRange(order.OrderDetails);
                _context.Orders.Remove(order);
                _context.SaveChanges();
            }
        }
    }
}
