using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Notes_Homework_11._1.Views.Note
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
